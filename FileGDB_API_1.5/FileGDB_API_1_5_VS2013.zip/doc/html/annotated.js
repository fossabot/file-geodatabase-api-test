var annotated =
[
    [ "FileGDBAPI", null, [
      [ "ErrorInfo", "namespace_file_g_d_b_a_p_i_1_1_error_info.html", null ],
      [ "SpatialReferences", "namespace_file_g_d_b_a_p_i_1_1_spatial_references.html", null ],
      [ "Geodatabase", "class_file_g_d_b_a_p_i_1_1_geodatabase.html", "class_file_g_d_b_a_p_i_1_1_geodatabase" ],
      [ "Row", "class_file_g_d_b_a_p_i_1_1_row.html", "class_file_g_d_b_a_p_i_1_1_row" ],
      [ "Table", "class_file_g_d_b_a_p_i_1_1_table.html", "class_file_g_d_b_a_p_i_1_1_table" ],
      [ "EnumRows", "class_file_g_d_b_a_p_i_1_1_enum_rows.html", "class_file_g_d_b_a_p_i_1_1_enum_rows" ],
      [ "SpatialReference", "class_file_g_d_b_a_p_i_1_1_spatial_reference.html", null ],
      [ "GeometryDef", "class_file_g_d_b_a_p_i_1_1_geometry_def.html", null ],
      [ "FieldDef", "class_file_g_d_b_a_p_i_1_1_field_def.html", null ],
      [ "IndexDef", "class_file_g_d_b_a_p_i_1_1_index_def.html", null ],
      [ "FieldInfo", "class_file_g_d_b_a_p_i_1_1_field_info.html", "class_file_g_d_b_a_p_i_1_1_field_info" ],
      [ "ShapeBuffer", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html", "class_file_g_d_b_a_p_i_1_1_shape_buffer" ],
      [ "PointShapeBuffer", "class_file_g_d_b_a_p_i_1_1_point_shape_buffer.html", "class_file_g_d_b_a_p_i_1_1_point_shape_buffer" ],
      [ "MultiPointShapeBuffer", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer" ],
      [ "MultiPartShapeBuffer", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer" ],
      [ "MultiPatchShapeBuffer", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer" ],
      [ "ByteArray", "class_file_g_d_b_a_p_i_1_1_byte_array.html", "class_file_g_d_b_a_p_i_1_1_byte_array" ],
      [ "Envelope", "class_file_g_d_b_a_p_i_1_1_envelope.html", "class_file_g_d_b_a_p_i_1_1_envelope" ]
    ] ]
];