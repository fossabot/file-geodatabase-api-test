var class_file_g_d_b_a_p_i_1_1_shape_buffer =
[
    [ "ShapeBuffer", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#af8fd6a6a03ed90a10a72f754ae6ed9a6", null ],
    [ "~ShapeBuffer", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#ab35415ef0d109f60d47895c2f727e594", null ],
    [ "Allocate", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#a91bc28b541a651d996407623c7aba9ca", null ],
    [ "IsEmpty", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#a8cfc62c93df5b6e193c38d278da16d0c", null ],
    [ "SetEmpty", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#a4c3597cb4786abc56079c4e7c9a60d71", null ],
    [ "GetShapeType", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#aa9c74a1a4f1bc666e649f88991e9d1f6", null ],
    [ "GetGeometryType", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#aded6b485aa42d74ede6c95a4fc777368", null ],
    [ "shapeBuffer", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#ad4b7182a4bbe49fca6cfebb057f665eb", null ],
    [ "allocatedLength", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#ab5bdd670c53eb89bcf182c22b5a5d956", null ],
    [ "inUseLength", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html#aad329ab06612257b4591b4f189986d0d", null ]
];