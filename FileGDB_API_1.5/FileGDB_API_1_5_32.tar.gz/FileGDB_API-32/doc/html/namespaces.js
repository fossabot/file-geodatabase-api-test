var namespaces =
[
    [ "FileGDBAPI", null, [
      [ "ErrorInfo", "namespace_file_g_d_b_a_p_i_1_1_error_info.html", null ],
      [ "SpatialReferences", "namespace_file_g_d_b_a_p_i_1_1_spatial_references.html", null ]
    ] ]
];