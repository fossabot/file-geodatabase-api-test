var class_file_g_d_b_a_p_i_1_1_envelope =
[
    [ "Envelope", "class_file_g_d_b_a_p_i_1_1_envelope.html#afdc5654073c510370fb589d008008950", null ],
    [ "~Envelope", "class_file_g_d_b_a_p_i_1_1_envelope.html#aa175e82de06da0a7cee25000ebf2c98a", null ],
    [ "IsEmpty", "class_file_g_d_b_a_p_i_1_1_envelope.html#a26a23f5fb5a2ac58b17afd37e2e5d6fe", null ],
    [ "SetEmpty", "class_file_g_d_b_a_p_i_1_1_envelope.html#a73665d128bceed4ad77418f456d1d976", null ],
    [ "xMin", "class_file_g_d_b_a_p_i_1_1_envelope.html#a92925fb70c4c3b34b3c6a62f5f962db3", null ],
    [ "yMin", "class_file_g_d_b_a_p_i_1_1_envelope.html#a249f753216ef17884efc431a25be26d4", null ],
    [ "xMax", "class_file_g_d_b_a_p_i_1_1_envelope.html#aff040626a9718ffb4f9510716bdc1e16", null ],
    [ "yMax", "class_file_g_d_b_a_p_i_1_1_envelope.html#a8e3f3621d895cc73c5f32771b9fe12c1", null ],
    [ "zMin", "class_file_g_d_b_a_p_i_1_1_envelope.html#a47480ffdeac0f4b1ed2ef346164028bf", null ],
    [ "zMax", "class_file_g_d_b_a_p_i_1_1_envelope.html#a54bb18f79bcbe022605fcc5f79c9c0ee", null ]
];