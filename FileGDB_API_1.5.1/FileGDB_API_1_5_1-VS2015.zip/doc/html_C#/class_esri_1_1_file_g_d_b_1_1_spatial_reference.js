var class_esri_1_1_file_g_d_b_1_1_spatial_reference =
[
    [ "SpatialReference", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a25541b346e28b7f27fc0a64dbdc16732", null ],
    [ "spatialReferenceText", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#aff22fc56e20e1c5957fd3a0029894103", null ],
    [ "spatialReferenceID", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#ad7ee524372ccfdc7d632d6efaed6d33f", null ],
    [ "xFalseOrigin", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a9b00a90cae0ea8d5eb586a06dcad3f72", null ],
    [ "yFalseOrigin", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#ac00a26255ac798fb8b63720b747d9171", null ],
    [ "xyResolution", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#ad5cafbf996bd896799d33746f33f3fbd", null ],
    [ "xyTolerance", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a2c9654521244de44580a1ddf47fca1fd", null ],
    [ "zFalseOrigin", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#ae98eb69e97bc0549d66a095e6566a5f6", null ],
    [ "zResolution", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a841e1f3d9d0f715ad4882d93006ca8ac", null ],
    [ "zTolerance", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a1e1741d2caa326df10e51b8adf3bc4ea", null ],
    [ "mFalseOrigin", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#af23fc7a27df47efc328f57c28f48055a", null ],
    [ "mResolution", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a0386d468fa9da533ea51ffddd3dbc792", null ],
    [ "mTolerance", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html#a5fe88356c297d5cef7415247b2026eb8", null ]
];