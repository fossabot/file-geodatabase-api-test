var annotated =
[
    [ "Esri", null, [
      [ "FileGDB", null, [
        [ "ByteArray", "class_esri_1_1_file_g_d_b_1_1_byte_array.html", "class_esri_1_1_file_g_d_b_1_1_byte_array" ],
        [ "Envelope", "class_esri_1_1_file_g_d_b_1_1_envelope.html", "class_esri_1_1_file_g_d_b_1_1_envelope" ],
        [ "ErrorInfo", "class_esri_1_1_file_g_d_b_1_1_error_info.html", null ],
        [ "FieldDef", "class_esri_1_1_file_g_d_b_1_1_field_def.html", "class_esri_1_1_file_g_d_b_1_1_field_def" ],
        [ "FileGDBException", "class_esri_1_1_file_g_d_b_1_1_file_g_d_b_exception.html", "class_esri_1_1_file_g_d_b_1_1_file_g_d_b_exception" ],
        [ "Geodatabase", "class_esri_1_1_file_g_d_b_1_1_geodatabase.html", "class_esri_1_1_file_g_d_b_1_1_geodatabase" ],
        [ "GeometryDef", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html", "class_esri_1_1_file_g_d_b_1_1_geometry_def" ],
        [ "IndexDef", "class_esri_1_1_file_g_d_b_1_1_index_def.html", "class_esri_1_1_file_g_d_b_1_1_index_def" ],
        [ "MultiPartShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer" ],
        [ "MultiPatchShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_multi_patch_shape_buffer.html", "class_esri_1_1_file_g_d_b_1_1_multi_patch_shape_buffer" ],
        [ "MultiPointShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer" ],
        [ "PointShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_point_shape_buffer.html", "class_esri_1_1_file_g_d_b_1_1_point_shape_buffer" ],
        [ "Raster", "class_esri_1_1_file_g_d_b_1_1_raster.html", null ],
        [ "Row", "class_esri_1_1_file_g_d_b_1_1_row.html", "class_esri_1_1_file_g_d_b_1_1_row" ],
        [ "ShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html", "class_esri_1_1_file_g_d_b_1_1_shape_buffer" ],
        [ "SpatialReference", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html", "class_esri_1_1_file_g_d_b_1_1_spatial_reference" ],
        [ "SpatialReferenceInfo", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info" ],
        [ "SpatialReferenceInfoCollection", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info_collection.html", null ],
        [ "Table", "class_esri_1_1_file_g_d_b_1_1_table.html", "class_esri_1_1_file_g_d_b_1_1_table" ]
      ] ]
    ] ]
];