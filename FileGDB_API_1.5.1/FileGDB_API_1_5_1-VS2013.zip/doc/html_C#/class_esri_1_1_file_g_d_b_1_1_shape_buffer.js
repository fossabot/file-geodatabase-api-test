var class_esri_1_1_file_g_d_b_1_1_shape_buffer =
[
    [ "ShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a2d5af00803f7a1695c29c92a1c23cbfc", null ],
    [ "Allocate", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a909ed9beb2a18aa35a63c61f61eb7cf7", null ],
    [ "SetEmpty", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a3255d33595427f67b28a8cb13d190c63", null ],
    [ "shapeBuffer", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#afb26c594cef8170f1620d143f277f02c", null ],
    [ "allocatedLength", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a5596ac3d32fd0dc28362ce2d7e14370e", null ],
    [ "inUseLength", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a992f3266ba508d8861525f2fbe62b875", null ],
    [ "IsEmpty", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a2e55737750af62fefbadf4d68d7c51e6", null ],
    [ "shapeType", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a9c956dcf46ded0978d800d58027a0cfe", null ],
    [ "geometryType", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html#a8023a93a515c83eb283a1f28b58d3881", null ]
];