var class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer =
[
    [ "Setup", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a4715d8854fbce3c23453bba42e1e5847", null ],
    [ "CalculateExtent", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a43f78e6c076b3c77b67c61a6a7aee05a", null ],
    [ "Extent", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#ab6fccd0e1dcf985afeeecf4d695a9bfd", null ],
    [ "NumPoints", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#af0608f8168ec76748365823e72735b0d", null ],
    [ "Points", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a5584c575e7dc6e7b733ca604ce4f9d9d", null ],
    [ "ZExtent", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a6815cd4f4b85b8fbb43b9d511ae4e51b", null ],
    [ "Zs", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a3af117b35140e37d4361eb1f1e375150", null ],
    [ "MExtent", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a66ac09bdf3f8d1cead5fa2834c48de1f", null ],
    [ "Ms", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a3775f2928fb9b721533bf60a643e4997", null ],
    [ "IDs", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html#a3c9f124766b60c82199a58cde935a70e", null ]
];