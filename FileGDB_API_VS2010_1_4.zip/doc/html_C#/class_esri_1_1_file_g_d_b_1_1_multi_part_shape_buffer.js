var class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer =
[
    [ "Setup", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#afe58e8973738f4abd625a2fe24e528d5", null ],
    [ "Setup", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#ae694e1f1e5394754ff7f44c30db95675", null ],
    [ "CalculateExtent", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#ae8119fcedbe5681ccfb85f0c4aaed192", null ],
    [ "PackCurves", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a65a96953b5833ff868b85fcf81b1d679", null ],
    [ "Extent", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#abc3864748f2883b729e94bf16742d740", null ],
    [ "NumParts", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a53ffb8a74bf20d4facb9c7207bfe4a69", null ],
    [ "NumPoints", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#ac14410ea2f36ee05098cc6be35789338", null ],
    [ "Parts", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a800c11b90432383b7fca66afb099686c", null ],
    [ "Points", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#afcf777d2d807fd7621ad8fd69204a2d8", null ],
    [ "ZExtent", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#aa5762757a91c8c85aa72c908e1644855", null ],
    [ "Zs", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a89b8321dd05b225318fa27a4c629373d", null ],
    [ "MExtent", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a291892c07417b39ab8934031680e4a15", null ],
    [ "Ms", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#acd7c5716bea40f9342c32fac74f832c5", null ],
    [ "NumCurves", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a4f6d922f9741e3519e1abc9404ae0dac", null ],
    [ "Curves", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#aa8b94b5b0ed915ab662e41256361b6e8", null ],
    [ "IDs", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html#a45fbc9def57689871100291d7a7ce1d0", null ]
];